package cn.finalteam.galleryfinal;

/**
 * Desction:
 * Author:pengjianbo
 * Date:2016/1/9 0009 18:30
 */
class Global {

    public static PhotoSelectActivity mPhotoSelectActivity;

}
