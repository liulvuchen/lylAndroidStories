# AndroidRulerView
android自定义尺子
#效果
![image](https://github.com/dalong982242260/AndroidRulerView/blob/master/gif/ruler.gif?raw=true)