/** Automatically generated file. DO NOT MODIFY */
package com.wawi.ruler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}