# ruler
android项目开发源码示例
通过android的view实现直尺以及圆尺的测量功能。
