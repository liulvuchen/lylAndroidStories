/** Automatically generated file. DO NOT MODIFY */
package com.wawi.cycleruler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}